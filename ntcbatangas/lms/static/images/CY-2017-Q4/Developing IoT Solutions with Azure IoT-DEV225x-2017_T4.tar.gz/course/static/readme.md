This folder is used to store image files and other linked reference documents for the entire course. In edX Studio, all linked images (and other linked files) are located in a single folder, so we need to ensure that file names are unique.

Use a naming convention for image and other linked files. The naming convention needs to include a prefix to identify the module followed by a descriptive title for the file. 

Examples: 
- Mod01_AzurePortalOverview.png

